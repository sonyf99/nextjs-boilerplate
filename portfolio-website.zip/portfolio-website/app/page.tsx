import Link from "next/link";
import Image from "next/image";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-100 text-gray-800 p-6">
      <header className="mb-12 text-center">
        <h1 className="text-4xl font-bold mb-2">Sony Fedhila</h1>
        <p className="text-lg">Creative Technologist | Product Enthusiast</p>
      </header>

      <section className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-6">My Products</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="shadow-xl">
            <Image
              src="/product1.png"
              alt="Product 1"
              width={500}
              height={300}
              className="rounded-t-2xl object-cover"
            />
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">SmartHome Controller</h3>
              <p className="text-sm text-gray-600 mb-4">
                A device to automate your home appliances with intuitive mobile app integration.
              </p>
              <Link href="/products/smarthome">
                <Button>View Details</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="shadow-xl">
            <Image
              src="/product2.png"
              alt="Product 2"
              width={500}
              height={300}
              className="rounded-t-2xl object-cover"
            />
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">EcoCharge Power Bank</h3>
              <p className="text-sm text-gray-600 mb-4">
                A solar-powered power bank designed for travelers and eco-conscious users.
              </p>
              <Link href="/products/ecocharge">
                <Button>View Details</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>
    </main>
  );
}
