export default function SmartHomePage() {
  return (
    <main className="min-h-screen p-8 bg-white text-gray-800">
      <h1 className="text-3xl font-bold mb-4">SmartHome Controller</h1>
      <p className="mb-2">
        The SmartHome Controller allows you to automate your appliances and monitor energy usage via mobile app.
      </p>
      <ul className="list-disc ml-6 text-sm text-gray-600">
        <li>Wi-Fi and Bluetooth support</li>
        <li>Works with Alexa and Google Assistant</li>
        <li>Energy efficiency dashboard</li>
      </ul>
    </main>
  );
}
