export default function EcoChargePage() {
  return (
    <main className="min-h-screen p-8 bg-white text-gray-800">
      <h1 className="text-3xl font-bold mb-4">EcoCharge Power Bank</h1>
      <p className="mb-2">
        EcoCharge is a solar-powered power bank built for durability and sustainability.
      </p>
      <ul className="list-disc ml-6 text-sm text-gray-600">
        <li>10,000 mAh capacity</li>
        <li>Dual USB output</li>
        <li>Solar and USB-C input options</li>
      </ul>
    </main>
  );
}
